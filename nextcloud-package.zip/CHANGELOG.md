Changelog
=========

The change log is at [https://nextcloud.com/changelog/](https://nextcloud.com/changelog/).