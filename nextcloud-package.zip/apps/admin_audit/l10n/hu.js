OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Audit / naplózás",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Naplózási funkciókat biztosít a Nexcloudhoz, például a fájlelérések vagy az érzékeny műveletek naplózhatók lesznek."
},
"nplurals=2; plural=(n != 1);");
