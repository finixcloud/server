OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoria / Registro",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Fornece recursos de registro para Nextcloud, como registros de acesso a arquivos ou outras ações confidenciais."
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
