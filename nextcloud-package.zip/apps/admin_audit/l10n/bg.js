OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Одитиране/създаване на регистри",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Предоставя възможности за регистриране в Nextcloud, като например достъп до файлове за регистриране или други чувствителни действия."
},
"nplurals=2; plural=(n != 1);");
