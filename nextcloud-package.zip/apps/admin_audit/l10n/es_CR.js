OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoría / Registros"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
