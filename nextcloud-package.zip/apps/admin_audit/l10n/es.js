OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoría / Registro",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Ofrece a Nextcloud capacidades de registro tales como registrar los accesos a archivos u otras acciones sensibles."
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
