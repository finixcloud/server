OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Ekzamenado / Protokolado",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Provizi protokolado-kapablojn por Nextcloud, kiel ekzemple protokolado de aliroj al dosieroj aŭ aliaj delikataj agoj."
},
"nplurals=2; plural=(n != 1);");
