OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditeerimine / Logimine",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Lisab Nextcloudile logimisvõimekuse, millega on võimalik jälgida näiteks failide kasutamist või teisi tundlikke tegevusi."
},
"nplurals=2; plural=(n != 1);");
