OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Revision/Logning",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Bidrager med lognings funktionalitet til Nextcloud, såsom logning af fil tilgang eller andre sensitive handlinger"
},
"nplurals=2; plural=(n != 1);");
