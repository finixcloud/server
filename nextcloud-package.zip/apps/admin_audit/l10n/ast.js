OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoría / Rexistru",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Forne la capacidá de rexistrar, por exemplu, l'accesu a los ficheros o a otres aiciones sensibles de Nextcloud"
},
"nplurals=2; plural=(n != 1);");
