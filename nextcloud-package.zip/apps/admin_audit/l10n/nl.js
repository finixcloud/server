OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Audit / Logging",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Biedt loggingfuncties voor Nextcloud, zoals het loggen van bestandstoegang of anderszins gevoelige acties."
},
"nplurals=2; plural=(n != 1);");
