OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Audit / Istoric",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Provesís de capacitats d’audit per Nextcloud coma enregistrar los accèsses als fichièrs o las accions sensiblas."
},
"nplurals=2; plural=(n > 1);");
