OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditing / Logging",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions."
},
"nplurals=2; plural=(n != 1);");
