OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "ऑडिटिंग/लॉगिंग",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "नेक्स्टक्लाउड के लिए लॉगिंग क्षमताएं प्रदान करता है जैसे फ़ाइल एक्सेस या अन्यथा संवेदनशील कार्यों को लॉग करना।"
},
"nplurals=2; plural=(n != 1);");
