OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Denetim / Günlük Kaydı",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Nextcloud için dosyalara erişim ve diğer önemli işlemlerin günlük kaydınının tutulması özelliği sağlar."
},
"nplurals=2; plural=(n > 1);");
