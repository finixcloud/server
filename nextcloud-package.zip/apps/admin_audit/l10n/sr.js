OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Праћење / Бележење",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Даје Некстклауду могућност бележења, попут приступа фајловима или других осетљивих радњи."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
