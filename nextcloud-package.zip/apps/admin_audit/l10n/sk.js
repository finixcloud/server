OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditovanie / zaznamenávanie udalostí",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Poskytuje možnosť zaznamenávania udalostí pre Nextcloud, ako je napríklad prístup k súborom alebo iných citlivých akcií."
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
