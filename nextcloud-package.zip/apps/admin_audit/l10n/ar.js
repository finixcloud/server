OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "التدقيق / السجلات",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "خاصية سجلات المراقبة لـ نكست كلاود مثل الوصول إلى سجلات الملفات أو المعلومات الحساسة الاخرى."
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
