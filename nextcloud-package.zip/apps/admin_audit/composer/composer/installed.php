<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'reference' => 'dd3d689e04a5e1d558da937ca72980e0e2c7c404',
        'type' => 'library',
        'install_path' => __DIR__ . '/../',
        'aliases' => array(),
        'dev' => false,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'reference' => 'dd3d689e04a5e1d558da937ca72980e0e2c7c404',
            'type' => 'library',
            'install_path' => __DIR__ . '/../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
