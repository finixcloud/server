OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Birleşik Bulut API",
    "Enable clouds to communicate with each other and exchange data" : "Karşılıklı iletişim kurmak için bulut hizmetlerini kullanın",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Birleşik Bulut API, farklı Nextcloud kopyalarının birbiri ile iletişim kurarak karşılıklı veri aktarmasını sağlar."
},
"nplurals=2; plural=(n > 1);");
