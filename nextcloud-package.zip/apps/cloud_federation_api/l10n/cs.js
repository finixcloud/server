OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API pro federovaný cloud",
    "Enable clouds to communicate with each other and exchange data" : "Umožňuje cloudům vzájemně komunikovat a vyměňovat si data",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "API pro federovaný cloud umožňuje různým instancím Nextcloud vzájemně komunikovat a vyměňovat si data."
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
