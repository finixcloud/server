OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Ενεργοποιήστε τις εγκαταστάσεις clouds για επικοινωνία μεταξύ τους και ανταλλαγή δεδομένων",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Το Cloud Federation API επιτρέπει σε διάφορες εγκαταστάσεις Nextcloud να επικοινωνούν μεταξύ τους και να ανταλλάσσουν δεδομένα."
},
"nplurals=2; plural=(n != 1);");
