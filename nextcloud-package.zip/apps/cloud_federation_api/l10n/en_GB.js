OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Enable clouds to communicate with each other and exchange data",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data."
},
"nplurals=2; plural=(n != 1);");
