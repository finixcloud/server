OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Федерален Cloud API",
    "Enable clouds to communicate with each other and exchange data" : "Овозможете на Cloud-от да комуницира со сите други и да разменува податоци",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Федерален Cloud API овозможува различни истанци да комуницираат помеѓу себе и да разменуваат податоци."
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
