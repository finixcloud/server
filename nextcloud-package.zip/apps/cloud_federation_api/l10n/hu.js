OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Felhő föderációs API",
    "Enable clouds to communicate with each other and exchange data" : "A felhőszolgáltatások egymás közti kommunikációjának és adatcseréjének lehetővé tétele",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "A felhő föderációs API segítségével a különféle Nextcloud példányok képesek lesznek egymás között kommunikálni és adatokat cserélni."
},
"nplurals=2; plural=(n != 1);");
