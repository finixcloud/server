OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "クラウドフェデレーションAPI",
    "Enable clouds to communicate with each other and exchange data" : "クラウドが相互に通信し、データを交換できるようにします",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Cloud Federation APIにより、さまざまなNextcloudインスタンスが相互に通信し、データを交換することができるようになります。"
},
"nplurals=1; plural=0;");
