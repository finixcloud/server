OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "联合云API",
    "Enable clouds to communicate with each other and exchange data" : "使云能够相互通信并交换数据",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "联合云API使各种 Nextcloud 实例可以相互通信并交换数据。"
},
"nplurals=1; plural=0;");
