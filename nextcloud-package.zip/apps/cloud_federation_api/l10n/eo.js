OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API de Nuba Federacio",
    "Enable clouds to communicate with each other and exchange data" : "Ebligi interkomunikadon inter diversaj nuboj kaj la interŝanĝon de datumoj",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "La API de Nuba Federacio ebligas diversajn instancojn de Nextcloud interkomuniki kaj interŝanĝi datumojn inter si."
},
"nplurals=2; plural=(n != 1);");
