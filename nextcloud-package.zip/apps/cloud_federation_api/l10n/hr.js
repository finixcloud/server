OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API udruženog oblaka",
    "Enable clouds to communicate with each other and exchange data" : "Omogućite međusobnu komunikaciju i razmjenu podataka među oblacima",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "API udruženog oblaka omogućuje raznim instancama Nextclouda da međusobno komuniciraju i razmjenjuju podatke."
},
"nplurals=3; plural=n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2;");
