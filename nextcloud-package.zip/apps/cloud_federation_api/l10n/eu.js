OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation APIa",
    "Enable clouds to communicate with each other and exchange data" : "Aukera ematen du beste hodeiekin komunikatzeko eta datuak trukatzeko.",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Cloud Federation APIak aukera ematen du hainbat Nextcloud instantziaren artean komunikatzeko eta datuak trukatzeko. "
},
"nplurals=2; plural=(n != 1);");
