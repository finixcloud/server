OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Pilve Liit API",
    "Enable clouds to communicate with each other and exchange data" : "Luba pilvedel suhelda omavahel ja vahetada andmeid",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Pilve Liit API lubab erinevad Nextcloud'i osadel suhelda omavahel ja vahetada andmeid"
},
"nplurals=2; plural=(n != 1);");
