OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API de federació de núvols",
    "Enable clouds to communicate with each other and exchange data" : "Permeteu que els núvols es comuniquin entre si i intercanviïn dades",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "L'API de federació de núvols permet que diverses instàncies del Nextcloud es comuniquin entre si i intercanviïn dades."
},
"nplurals=2; plural=(n != 1);");
