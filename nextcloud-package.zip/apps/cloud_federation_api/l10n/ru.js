OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API облачной федерации",
    "Enable clouds to communicate with each other and exchange data" : "Позволяют облакам связываться друг с другом и обмениваться данными",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "API облачной федерации позволяет разным экземплярам Nextcloud связываться друг с другом и обмениваться данными."
},
"nplurals=4; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<12 || n%100>14) ? 1 : n%10==0 || (n%10>=5 && n%10<=9) || (n%100>=11 && n%100<=14)? 2 : 3);");
